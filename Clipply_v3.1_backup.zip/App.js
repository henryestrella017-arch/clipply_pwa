// App.js — Clipply v3.1
// Base estilo TikTok + Filtros + Modal + Inbox/DM + MENÚ HOME DESPLEGABLE
// ✔ Sin dependencias externas
// ✔ iPhone/Expo Go estable (teclado no tapa, sin flicker)

import React, { useMemo, useRef, useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  ScrollView,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Modal,
} from 'react-native';

const { height: SCREEN_H, width: SCREEN_W } = Dimensions.get('window');

const PROFILES = [
  { id: 'u1', name: 'Henry', handle: '@henry', badge: '🟢' },
  { id: 'u2', name: 'Hijo', handle: '@hijo', badge: '🔵' },
  { id: 'u3', name: 'Invitado', handle: '@invitado', badge: '🟣' },
];

const FEED = [
  { id: 'p1', author: '@calmpower', title: 'La fuerza en medio de la prueba', likes: 1240, comments: 89 },
  { id: 'p2', author: '@coretik2', title: 'Tips para crecer en TikTok hoy', likes: 980, comments: 47 },
  { id: 'p3', author: '@henry_e', title: 'Fe cuando hay dudas', likes: 1530, comments: 112 },
  { id: 'p4', author: '@gaming', title: 'Prototipo estable sin parpadeo', likes: 765, comments: 22 },
  { id: 'p5', author: '@clipply', title: 'Swipe vertical estable', likes: 210, comments: 6 },
];

const pairKey = (a, b) => [a, b].sort().join('__');

export default function App() {
  const [tab, setTab] = useState('Home'); // Home | Discover | Inbox | Store | Profile
  const [topTab, setTopTab] = useState('ForYou');
  const [currentUserId, setCurrentUserId] = useState('u1');
  const currentUser = useMemo(() => PROFILES.find(p => p.id === currentUserId) || PROFILES[0], [currentUserId]);

  // Modal del feed
  const [modalOpen, setModalOpen] = useState(false);
  const [modalPost, setModalPost] = useState(null);
  const openPost = (post) => { setModalPost(post); setModalOpen(true); };
  const closePost = () => { setModalOpen(false); setModalPost(null); };

  // === MENÚ HOME DESPLEGABLE ===
  const [homeMenuOpen, setHomeMenuOpen] = useState(false);
  const toggleHomeMenu = () => setHomeMenuOpen(v => !v);
  const handleMenuAction = (key) => {
    if (key === 'inbox') setTab('Inbox');
    if (key === 'profile') setTab('Profile');
    if (key === 'discover') setTab('Discover');
    if (key === 'store') setTab('Store');
    setHomeMenuOpen(false);
  };

  // Inbox / DM
  const [inboxView, setInboxView] = useState({ mode: 'list', peerId: null }); // list | dm
  const [draft, setDraft] = useState('');
  const [dmStore, setDmStore] = useState(() => {
    const init = {};
    const seed = [
      { from: 'u1', to: 'u2', text: 'Hola! Probando DMs en Clipply.', t: Date.now() - 60000 },
      { from: 'u2', to: 'u1', text: 'Recibido, funciona perfecto 👌', t: Date.now() - 55000 },
      { from: 'u1', to: 'u3', text: 'Bienvenido a los DMs tipo TikTok.', t: Date.now() - 30000 },
      { from: 'u3', to: 'u1', text: 'Gracias, se ve limpio y estable!', t: Date.now() - 29000 },
    ];
    seed.forEach(s => {
      const k = pairKey(s.from, s.to);
      (init[k] ||= []).push({
        id: 'm-' + Math.random().toString(36).slice(2),
        text: s.text,
        from: s.from,
        to: s.to,
        createdAt: s.t,
      });
    });
    return init;
  });

  const otherUsers = useMemo(() => PROFILES.filter(p => p.id !== currentUser.id), [currentUser.id]);

  const inboxThreads = useMemo(() => {
    const threads = [];
    otherUsers.forEach(peer => {
      const k = pairKey(currentUser.id, peer.id);
      const msgs = dmStore[k] || [];
      const last = msgs[msgs.length - 1];
      threads.push({
        peerId: peer.id,
        name: peer.name,
        handle: peer.handle,
        badge: peer.badge,
        lastText: last ? last.text : 'Nuevo chat',
        lastAt: last ? last.createdAt : 0,
        unread: 0,
      });
    });
    threads.sort((a, b) => (b.lastAt || 0) - (a.lastAt || 0));
    return threads;
  }, [dmStore, currentUser.id, otherUsers]);

  const openDM = (peerId) => setInboxView({ mode: 'dm', peerId });
  const backToInbox = () => { setInboxView({ mode: 'list', peerId: null }); setDraft(''); };

  const sendDM = () => {
    const text = draft.trim();
    if (!text || inboxView.mode !== 'dm' || !inboxView.peerId) return;
    const peerId = inboxView.peerId;
    const k = pairKey(currentUser.id, peerId);
    const msg = { id: 'm-' + Math.random().toString(36).slice(2), text, from: currentUser.id, to: peerId, createdAt: Date.now() };
    setDmStore(prev => ({ ...prev, [k]: (prev[k] || []).concat(msg) }));
    setDraft('');
    setTimeout(() => {
      setDmStore(prev => {
        const copy = { ...prev };
        const reply = { id: 'm-' + Math.random().toString(36).slice(2), text: 'Recibido ✅', from: peerId, to: currentUser.id, createdAt: Date.now() };
        copy[k] = (copy[k] || []).concat(reply);
        return copy;
      });
    }, 250);
  };

  // Feed
  const listRef = useRef(null);
  const renderPost = ({ item }) => (
    <TouchableOpacity activeOpacity={0.9} onPress={() => openPost(item)}>
      <View style={[styles.post, { width: SCREEN_W, height: SCREEN_H - 120 }]}>
        <View style={styles.postTop}>
          <Text style={styles.author}>{item.author}</Text>
          <View style={styles.topTabs}>
            <TouchableOpacity onPress={() => setTopTab('ForYou')} style={[styles.topTabBtn, topTab === 'ForYou' && styles.topTabBtnActive]}>
              <Text style={[styles.topTabTxt, topTab === 'ForYou' && styles.topTabTxtActive]}>For You</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setTopTab('Live')} style={[styles.topTabBtn, topTab === 'Live' && styles.topTabBtnActive]}>
              <Text style={[styles.topTabTxt, topTab === 'Live' && styles.topTabTxtActive]}>Live</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.mockVideo}>
          <Text style={styles.mockTitle}>{item.title}</Text>
          <Text style={styles.mockHint}>Toca para ver detalles</Text>
        </View>

        <View style={styles.sideActions}>
          <View style={styles.actionBtn}><Text style={styles.actionIcon}>❤️</Text><Text style={styles.actionTxt}>{item.likes}</Text></View>
          <View style={styles.actionBtn}><Text style={styles.actionIcon}>💬</Text><Text style={styles.actionTxt}>{item.comments}</Text></View>
          <View style={styles.actionBtn}><Text style={styles.actionIcon}>↗️</Text><Text style={styles.actionTxt}>Share</Text></View>
        </View>

        <View style={styles.caption}><Text style={styles.captionTxt}>{item.author} • #{item.id}</Text></View>
      </View>
    </TouchableOpacity>
  );

  // === Pantallas ===
  const HomeScreen = (
    <View style={styles.screen}>
      {/* Top de Home con botón de menú */}
      <View style={styles.globalTop}>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <TouchableOpacity onPress={toggleHomeMenu} style={styles.topIcon}><Text style={styles.topIconTxt}>☰</Text></TouchableOpacity>
          <Text style={[styles.brand, { marginLeft: 8 }]}>Clipply</Text>
        </View>
        <View style={styles.globalTopRight}>
          <TouchableOpacity style={styles.topIcon}><Text style={styles.topIconTxt}>🔍</Text></TouchableOpacity>
          <TouchableOpacity style={styles.topIcon} onPress={() => setTab('Inbox')}><Text style={styles.topIconTxt}>✉️</Text></TouchableOpacity>
        </View>
      </View>

      <FlatList
        ref={listRef}
        data={FEED}
        keyExtractor={(it) => it.id}
        renderItem={renderPost}
        pagingEnabled
        showsVerticalScrollIndicator={false}
        decelerationRate="fast"
        snapToAlignment="start"
        bounces={false}
      />

      {/* Menú Home desplegable */}
      <Modal visible={homeMenuOpen} animationType="fade" transparent onRequestClose={() => setHomeMenuOpen(false)}>
        <TouchableOpacity activeOpacity={1} onPress={() => setHomeMenuOpen(false)} style={styles.menuBackdrop}>
          <TouchableOpacity activeOpacity={1} onPress={() => {}} style={styles.menuCard}>
            <Text style={styles.menuTitle}>Funciones</Text>

            <View style={styles.menuGrid}>
              <MenuItem icon="➕" label="Crear Post" onPress={() => handleMenuAction('create')} />
              <MenuItem icon="⬆️" label="Subir Video" onPress={() => handleMenuAction('upload')} />
              <MenuItem icon="📷" label="Cámara" onPress={() => handleMenuAction('camera')} />
              <MenuItem icon="🔴" label="Ir en Vivo" onPress={() => handleMenuAction('live')} />
              <MenuItem icon="📈" label="Analíticas" onPress={() => handleMenuAction('analytics')} />
              <MenuItem icon="🗂️" label="Borradores" onPress={() => handleMenuAction('drafts')} />
              <MenuItem icon="✉️" label="Inbox" onPress={() => handleMenuAction('inbox')} />
              <MenuItem icon="🧭" label="Descubrir" onPress={() => handleMenuAction('discover')} />
              <MenuItem icon="🛍️" label="Tienda" onPress={() => handleMenuAction('store')} />
              <MenuItem icon="👤" label="Perfil" onPress={() => handleMenuAction('profile')} />
              <MenuItem icon="⚙️" label="Ajustes" onPress={() => handleMenuAction('settings')} />
            </View>

            {/* Cambio de perfil dentro del menú */}
            <Text style={[styles.menuSubtitle, { marginTop: 14 }]}>Perfil activo</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.profilesRow}>
              {PROFILES.map(p => {
                const active = p.id === currentUserId;
                return (
                  <TouchableOpacity key={p.id} onPress={() => setCurrentUserId(p.id)} style={[styles.pill, active && styles.pillActive]}>
                    <Text style={[styles.pillTxt, active && styles.pillTxtActive]}>{p.badge} {p.name}</Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </View>
  );

  const DiscoverScreen = (
    <View style={styles.screenCenter}>
      <Text style={styles.title}>Descubrir</Text>
      <Text style={styles.sub}>Búsqueda, tendencias y categorías (placeholder).</Text>
    </View>
  );

  const StoreScreen = (
    <View style={styles.screenCenter}>
      <Text style={styles.title}>Tienda (Camel)</Text>
      <Text style={styles.sub}>Caravana/tienda futura (placeholder).</Text>
    </View>
  );

  const ProfileScreen = (
    <View style={styles.screenCenter}>
      <Text style={styles.title}>Perfil</Text>
      <Text style={styles.sub}>{currentUser.name} {currentUser.badge} — {currentUser.handle}</Text>
      <Text style={[styles.sub, { marginTop: 12 }]}>Cambia de perfil:</Text>
      <View style={{ flexDirection: 'row', marginTop: 8 }}>
        {PROFILES.map(p => {
          const active = p.id === currentUserId;
          return (
            <TouchableOpacity key={p.id} onPress={() => setCurrentUserId(p.id)} style={[styles.pill, active && styles.pillActive]}>
              <Text style={[styles.pillTxt, active && styles.pillTxtActive]}>{p.badge} {p.name}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  // Inbox / DM
  const InboxList = (
    <View style={styles.inboxWrap}>
      <View style={styles.inboxTop}>
        <Text style={styles.inboxBrand}>Inbox</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.profilesRow}>
          {PROFILES.map(p => {
            const active = p.id === currentUserId;
            return (
              <TouchableOpacity key={p.id} onPress={() => { setCurrentUserId(p.id); setInboxView({ mode: 'list', peerId: null }); }} style={[styles.pill, active && styles.pillActive]}>
                <Text style={[styles.pillTxt, active && styles.pillTxtActive]}>{p.badge} {p.name}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      <ScrollView style={styles.inboxList} contentContainerStyle={{ padding: 12 }}>
        {inboxThreads.length === 0 && <Text style={{ color: '#9AA4BD' }}>No tienes conversaciones.</Text>}
        {inboxThreads.map(th => (
          <TouchableOpacity key={th.peerId} style={styles.threadCard} onPress={() => openDM(th.peerId)}>
            <View style={styles.threadAvatar}><Text style={styles.threadAvatarTxt}>{th.badge}</Text></View>
            <View style={styles.threadMiddle}>
              <Text style={styles.threadName}>{th.name} <Text style={styles.threadHandle}>{th.handle}</Text></Text>
              <Text style={styles.threadLast} numberOfLines={1}>{th.lastText}</Text>
            </View>
            <View style={styles.threadRight}>{th.unread > 0 ? <View style={styles.unreadDot}><Text style={styles.unreadTxt}>{th.unread}</Text></View> : null}</View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );

  const DMView = (
    <KeyboardAvoidingView style={styles.dmWrap} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 8 : 0}>
      <View style={styles.dmTop}>
        <TouchableOpacity onPress={() => { setInboxView({ mode: 'list', peerId: null }); setDraft(''); }} style={styles.backBtn}>
          <Text style={styles.backTxt}>‹</Text>
        </TouchableOpacity>
        {(() => {
          const peer = PROFILES.find(p => p.id === inboxView.peerId);
          return <Text style={styles.dmTitle}>{peer ? `${peer.badge} ${peer.name}` : 'Chat'}</Text>;
        })()}
        <View style={{ width: 28 }} />
      </View>

      <ScrollView style={styles.messages} contentContainerStyle={styles.messagesContent} keyboardShouldPersistTaps="handled">
        {(dmStore[pairKey(currentUser.id, inboxView.peerId)] || []).map(m => {
          const mine = m.from === currentUser.id;
          return (
            <View key={m.id} style={[styles.msgRow, mine ? styles.msgRowMine : styles.msgRowOther]}>
              <View style={[styles.bubble, mine ? styles.bubbleMine : styles.bubbleOther]}>
                <Text style={[styles.msgText, mine ? styles.msgTextMine : styles.msgTextOther]}>{m.text}</Text>
                <Text style={[styles.meta, mine ? styles.metaMine : styles.metaOther]}>
                  {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
            </View>
          );
        })}
      </ScrollView>

      <View style={styles.inputBar}>
        <TextInput
          style={styles.input}
          value={draft}
          onChangeText={setDraft}
          placeholder="Escribe un mensaje…"
          placeholderTextColor="#8A8E99"
          multiline
          autoCapitalize="sentences"
          autoCorrect
          maxLength={1000}
        />
        <TouchableOpacity onPress={sendDM} style={[styles.sendBtn, !draft.trim() && { opacity: 0.5 }]} disabled={!draft.trim()}>
          <Text style={styles.sendTxt}>Enviar</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );

  const InboxScreen = inboxView.mode === 'list' ? InboxList : DMView;

  // Pantalla según tab
  let Screen = HomeScreen;
  if (tab === 'Discover') Screen = DiscoverScreen;
  if (tab === 'Inbox') Screen = InboxScreen;
  if (tab === 'Store') Screen = StoreScreen;
  if (tab === 'Profile') Screen = ProfileScreen;

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.flex}>{Screen}</View>

      {/* Bottom bar */}
      <View style={styles.bottomBar}>
        <TabBtn label="Inicio"   active={tab === 'Home'}    onPress={() => { setTab('Home'); setInboxView({ mode:'list', peerId:null }); }} />
        <TabBtn label="Descubrir" active={tab === 'Discover'} onPress={() => { setTab('Discover'); setInboxView({ mode:'list', peerId:null }); }} />
        <TabBtn label="Inbox"    active={tab === 'Inbox'}   onPress={() => setTab('Inbox')} />
        <TabBtn label="Tienda"   active={tab === 'Store'}   onPress={() => { setTab('Store'); setInboxView({ mode:'list', peerId:null }); }} />
        <TabBtn label="Perfil"   active={tab === 'Profile'} onPress={() => { setTab('Profile'); setInboxView({ mode:'list', peerId:null }); }} />
      </View>

      {/* Modal del feed (detalle) */}
      <Modal visible={modalOpen} animationType="slide" onRequestClose={closePost} transparent>
        <View style={styles.modalWrap}>
          <View style={styles.modalCard}>
            <View style={styles.modalTop}>
              <Text style={styles.modalTitle}>{modalPost ? modalPost.title : 'Contenido'}</Text>
              <TouchableOpacity onPress={closePost} style={styles.modalClose}><Text style={styles.modalCloseTxt}>✕</Text></TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <Text style={styles.modalText}>Mock del reproductor. Integramos expo-av cuando quieras.</Text>
              {modalPost && (
                <Text style={[styles.modalText, { marginTop: 8 }]}>
                  Autor: {modalPost.author} • Likes: {modalPost.likes} • Comentarios: {modalPost.comments}
                </Text>
              )}
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function TabBtn({ label, active, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={styles.tabBtn}>
      <Text style={[styles.tabTxt, active && styles.tabTxtActive]}>{label}</Text>
      {active ? <View style={styles.tabDot} /> : null}
    </TouchableOpacity>
  );
}

function MenuItem({ icon, label, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={styles.menuItem}>
      <View style={styles.menuIcon}><Text style={styles.menuIconTxt}>{icon}</Text></View>
      <Text style={styles.menuLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#0F1117' },
  flex: { flex: 1 },

  // Top (Home)
  globalTop: {
    height: 48,
    paddingHorizontal: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#232634',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#0F1117',
  },
  brand: { color: '#E6EAF2', fontSize: 18, fontWeight: '800' },
  globalTopRight: { flexDirection: 'row' },
  topIcon: { marginLeft: 0, marginRight: 8, padding: 6, borderRadius: 8, backgroundColor: '#1A1F2E' },
  topIconTxt: { color: '#E6EAF2', fontSize: 16 },

  // Pantallas base
  screen: { flex: 1, backgroundColor: '#0F1117' },
  screenCenter: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0F1117', padding: 20 },
  title: { color: '#E6EAF2', fontSize: 20, fontWeight: '700', marginBottom: 6 },
  sub: { color: '#9AA4BD', textAlign: 'center' },

  // Feed
  post: { position: 'relative', backgroundColor: '#0F1117' },
  postTop: { position: 'absolute', top: 10, left: 12, right: 12, zIndex: 10, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  author: { color: '#FFFFFF', fontWeight: '700' },
  topTabs: { flexDirection: 'row' },
  topTabBtn: { marginLeft: 8, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, backgroundColor: '#1A1F2E', borderWidth: 1, borderColor: '#2A3145' },
  topTabBtnActive: { backgroundColor: '#2B6EF2', borderColor: '#2B6EF2' },
  topTabTxt: { color: '#B8C1D9', fontSize: 12, fontWeight: '700' },
  topTabTxtActive: { color: '#FFFFFF' },

  mockVideo: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#141825', borderRadius: 12, marginHorizontal: 10, marginVertical: 10 },
  mockTitle: { color: '#E6EAF2', fontSize: 20, fontWeight: '800', textAlign: 'center', paddingHorizontal: 16 },
  mockHint: { marginTop: 8, color: '#9AA4BD' },

  sideActions: { position: 'absolute', right: 10, bottom: 90, alignItems: 'center' },
  actionBtn: { alignItems: 'center', marginVertical: 8 },
  actionIcon: { fontSize: 22, color: '#FFFFFF' },
  actionTxt: { color: '#FFFFFF', marginTop: 2, fontWeight: '700' },

  caption: { position: 'absolute', left: 12, right: 12, bottom: 16 },
  captionTxt: { color: '#D7DDEB' },

  // Bottom bar
  bottomBar: {
    height: 56, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#232634',
    backgroundColor: '#0F1117',
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around',
    paddingHorizontal: 6,
  },
  tabBtn: { alignItems: 'center', justifyContent: 'center' },
  tabTxt: { color: '#9AA4BD', fontSize: 12, fontWeight: '700' },
  tabTxtActive: { color: '#FFFFFF' },
  tabDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#2B6EF2', marginTop: 4 },

  // Inbox
  inboxWrap: { flex: 1, backgroundColor: '#0F1117' },
  inboxTop: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 10, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#232634', backgroundColor: '#0F1117' },
  inboxBrand: { color: '#E6EAF2', fontSize: 18, fontWeight: '800', marginBottom: 8 },

  profilesRow: { alignItems: 'center', paddingRight: 4, paddingVertical: 2 },
  pill: { marginRight: 8, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, backgroundColor: '#1A1F2E', borderWidth: 1, borderColor: '#2A3145' },
  pillActive: { backgroundColor: '#2B6EF2', borderColor: '#2B6EF2' },
  pillTxt: { color: '#B8C1D9', fontSize: 13, fontWeight: '700' },
  pillTxtActive: { color: '#FFFFFF' },

  inboxList: { flex: 1 },
  threadCard: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 8, borderRadius: 12, backgroundColor: '#121726', marginBottom: 10, borderWidth: 1, borderColor: '#20263A' },
  threadAvatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#1A1F2E', alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  threadAvatarTxt: { fontSize: 22, color: '#FFFFFF' },
  threadMiddle: { flex: 1 },
  threadName: { color: '#E6EAF2', fontWeight: '800' },
  threadHandle: { color: '#9AA4BD', fontWeight: '600' },
  threadLast: { color: '#9AA4BD', marginTop: 2 },
  threadRight: { paddingLeft: 8 },
  unreadDot: { minWidth: 18, height: 18, borderRadius: 9, backgroundColor: '#2B6EF2', alignItems: 'center', justifyContent: 'center' },
  unreadTxt: { color: '#fff', fontSize: 11, fontWeight: '800', paddingHorizontal: 5 },

  // DM
  dmWrap: { flex: 1, backgroundColor: '#0F1117' },
  dmTop: { height: 48, paddingHorizontal: 8, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#232634', alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  backBtn: { width: 28, height: 28, borderRadius: 6, backgroundColor: '#1A1F2E', alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: '#E6EAF2', fontSize: 18, fontWeight: '800' },
  dmTitle: { color: '#E6EAF2', fontSize: 16, fontWeight: '800' },

  messages: { flex: 1 },
  messagesContent: { paddingHorizontal: 12, paddingVertical: 12 },

  msgRow: { marginVertical: 6, flexDirection: 'row' },
  msgRowMine: { justifyContent: 'flex-end' },
  msgRowOther: { justifyContent: 'flex-start' },

  bubble: { maxWidth: '84%', borderRadius: 14, paddingHorizontal: 12, paddingVertical: 8 },
  bubbleMine: { backgroundColor: '#2B6EF2' },
  bubbleOther: { backgroundColor: '#1A1F2E', borderWidth: 1, borderColor: '#2A3145' },

  msgText: { fontSize: 15, lineHeight: 20 },
  msgTextMine: { color: 'white' },
  msgTextOther: { color: '#D7DDEB' },

  meta: { marginTop: 4, fontSize: 11 },
  metaMine: { color: 'rgba(255,255,255,0.85)' },
  metaOther: { color: '#9AA4BD' },

  // Modal feed
  modalWrap: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center', padding: 16 },
  modalCard: { width: '100%', borderRadius: 14, backgroundColor: '#141825', borderWidth: 1, borderColor: '#20263A' },
  modalTop: { height: 48, paddingHorizontal: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: '#232634', alignItems: 'center', flexDirection: 'row', justifyContent: 'space-between' },
  modalTitle: { color: '#E6EAF2', fontSize: 16, fontWeight: '800' },
  modalClose: { paddingHorizontal: 8, paddingVertical: 4, backgroundColor: '#1A1F2E', borderRadius: 8 },
  modalCloseTxt: { color: '#E6EAF2', fontSize: 16, fontWeight: '800' },
  modalBody: { padding: 14 },
  modalText: { color: '#D7DDEB' },

  // Menú Home
  menuBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'flex-end' },
  menuCard: { backgroundColor: '#0F1117', borderTopLeftRadius: 16, borderTopRightRadius: 16, borderTopWidth: StyleSheet.hairlineWidth, borderColor: '#232634', padding: 14 },
  menuTitle: { color: '#E6EAF2', fontSize: 18, fontWeight: '800', marginBottom: 8 },
  menuSubtitle: { color: '#9AA4BD', fontWeight: '700' },
  menuGrid: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 6 },
  menuItem: {
    width: (SCREEN_W - 14*2 - 12*2) / 3,
    margin: 6,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1, borderColor: '#20263A',
    backgroundColor: '#121726',
    alignItems: 'center', justifyContent: 'center',
  },
  menuIcon: { width: 38, height: 38, borderRadius: 19, backgroundColor: '#1A1F2E', alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  menuIconTxt: { color: '#FFFFFF', fontSize: 18, fontWeight: '800' },
  menuLabel: { color: '#E6EAF2', fontWeight: '700', fontSize: 12, textAlign: 'center' },
});
